package com.example.qatar_azkar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
